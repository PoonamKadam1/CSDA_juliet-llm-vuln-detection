#include "std_testcase.h"

#include <wchar.h>

namespace func1
{

static void func2()
{
    int * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new int;
        *data = 5;
        delete data;
    }
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        ;
    }
}

static void func3()
{
    int * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new int;
        *data = 5;
        delete data;
    }
    if(GLOBAL_CONST_TRUE)
    {
        ;
    }
}

static void func4()
{
    int * data;
    data = NULL;
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = new int;
        *data = 5;
    }
    if(GLOBAL_CONST_TRUE)
    {
        printIntLine(*data);
    }
}

static void func5()
{
    int * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new int;
        *data = 5;
    }
    if(GLOBAL_CONST_TRUE)
    {
        printIntLine(*data);
    }
}

void func6()
{
    func2();
    func3();
    func4();
    func5();
}

}
