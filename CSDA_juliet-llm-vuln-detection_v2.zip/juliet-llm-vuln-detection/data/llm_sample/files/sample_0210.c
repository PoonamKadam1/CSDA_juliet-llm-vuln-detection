#include "std_testcase.h"

#include <wchar.h>

static void func1()
{
    char * data;
    data = (char *)malloc(100*sizeof(char));
    if (data == NULL) {exit(-1);}
    memset(data, 'A', 50-1);
    data[50-1] = '\0';
    {
        char dest[50] = "";
        strncat(dest, data, strlen(data));
        dest[50-1] = '\0';
        printLine(data);
        free(data);
    }
}

void func2()
{
    func1();
}
