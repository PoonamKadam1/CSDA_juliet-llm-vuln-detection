#include <inttypes.h>
#include "std_testcase.h"

static void func1()
{
    int64_t data;
    data = 0LL;
    data = 2;
    {
        int64_t result = data + 1;
        printLongLongLine(result);
    }
}

static void func2()
{
    int64_t data;
    data = 0LL;
    fscanf (stdin, "%" SCNd64, &data);
    if (data < LLONG_MAX)
    {
        int64_t result = data + 1;
        printLongLongLine(result);
    }
    else
    {
        printLine("data value is too large to perform arithmetic safely.");
    }
}

void func3()
{
    func1();
    func2();
}
