#include "std_testcase.h"

#include <wchar.h>

void func1()
{
    wchar_t * data;
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';
    {
        wchar_t dest[50] = L"";
        wcscat(dest, data);
        printWLine(data);
        free(data);
    }
}
