#include "std_testcase.h"

#include <wchar.h>

namespace func1
{

static void func2()
{
    int * data;
    data = NULL;
    data = new int[100];
    {
        size_t i;
        for(i = 0; i < 100; i++)
        {
            data[i] = 5;
        }
    }
    printIntLine(data[0]);
}

static void func3()
{
    int * data;
    data = NULL;
    data = new int[100];
    {
        size_t i;
        for(i = 0; i < 100; i++)
        {
            data[i] = 5;
        }
    }
    delete [] data;
    ;
}

void func4()
{
    func2();
    func3();
}

}
