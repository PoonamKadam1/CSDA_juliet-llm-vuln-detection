#include "std_testcase.h"

#include <wchar.h>

namespace func1
{

static void func2()
{
    char * data;
    data = new char[100];
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";
        strcpy(dest, data);
        printLine(data);
        delete [] data;
    }
}

static void func3()
{
    char * data;
    data = new char[100];
    if(GLOBAL_CONST_TRUE)
    {
        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";
        strcpy(dest, data);
        printLine(data);
        delete [] data;
    }
}

void func4()
{
    func2();
    func3();
}

}
