#include "std_testcase.h"

#include <wchar.h>

void func1()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    memset(data, 'A', 100-1);
    data[100-1] = '\0';
    {
        char dest[50] = "";
        strcpy(dest, data);
        printLine(data);
    }
}
