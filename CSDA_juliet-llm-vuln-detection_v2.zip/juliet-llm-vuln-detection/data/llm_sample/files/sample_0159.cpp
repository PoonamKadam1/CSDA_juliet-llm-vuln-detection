#include "std_testcase.h"

#include <wchar.h>

namespace func1
{

static void func2()
{
    long * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new long;
        *data = 5L;
        delete data;
    }
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        ;
    }
}

static void func3()
{
    long * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new long;
        *data = 5L;
        delete data;
    }
    if(GLOBAL_CONST_TRUE)
    {
        ;
    }
}

static void func4()
{
    long * data;
    data = NULL;
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = new long;
        *data = 5L;
    }
    if(GLOBAL_CONST_TRUE)
    {
        printLongLine(*data);
    }
}

static void func5()
{
    long * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new long;
        *data = 5L;
    }
    if(GLOBAL_CONST_TRUE)
    {
        printLongLine(*data);
    }
}

void func6()
{
    func2();
    func3();
    func4();
    func5();
}

}
